import logo from './logo.svg';
import './App.css';
import PRegistration from './PRegistration';

function App() {
  return (
  <PRegistration/>
  );
}

export default App;
