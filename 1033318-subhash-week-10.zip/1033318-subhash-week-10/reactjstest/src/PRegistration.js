import React from "react";
import "./Registration.css";
import './image.js';
class PRegistration extends React.Component {
    constructor() {
        super();
        this.state = {
            fields: {},
            errors: {}
        }
        this.handleChange = this.handleChange.bind(this);
        this.formsubmit = this.formsubmit.bind(this);
    }
    handleChange(e) {
        let fields = this.state.fields;
        fields[e.target.name] = e.target.value;
        this.setState({
            fields
        })
    }
    formsubmit(e) {
        e.preventDefault();
        if (this.validate()) {
            alert("Successfully registered");
        }
    }
    validate() {
        let fields = this.state.fields;
        let errors = {};
        let fvalid = true;
        if (!fields["Enter Name"]) {
            fvalid = false;
            errors["entername"] ="*name cannot be empty";
        }
        if (!fields["Enter Phone Number"]) {
            fvalid = false;
            errors["phonenumber"] = "*phonenumber cannot be empty!";
        }
        if (!fields["Enter Address"]) {
            fvalid = false;
            errors["address"] = "*address should not be empty";
        }
        if(!fields["Enter Vendor ID"]){
            fvalid=false;
            errors["vendor"] = "*vendor field cannot be empty!."
        }  
        if(!fields["Enter Password"]){
            fvalid=false;
            errors["password"] = "*password field cannot be empty!."
        }  
        if(!fields["rpassword"]){
            fvalid = false;
            errors["rpassword"] = "*rPassword cannot be empty!";
        }
        this.setState({
            errors: errors
        });
        return fvalid;
    }
    render() {
        return (
            <div>
                <div id="register">
                    <form method="post" id="register-Form" name="userRegistrationform" onSubmit={this.formsubmit}>
                        <h1>Register New Vendor</h1>
                        <input type="text" placeholder="Enter Name" name="name" value={this.state.fields.entername} onChange={this.handleChange} />
                        <div className="errorvalue">{this.state.errors.entername}</div>
                        <input type="text" placeholder="Enter Phone Number"  name="phoneno" value={this.state.fields.phonenumber} onChange={this.handleChange} />
                        <div className="errorvalue">{this.state.errors.phonenumber}</div>
                        <input type="text" placeholder="Enter Address"  name="address" value={this.state.fields.address} onChange={this.handleChange} />
                        <div className="errorvalue">{this.state.errors.address}</div>
                        <input type="text" placeholder="Enter Vendor ID" name="vendor" value={this.state.fields.vendor} onChange={this.handleChange} />
                        <div className="errorvalue">{this.state.errors.vendor}</div>
                        <input type="text" placeholder="Enter Password"  name="password" value={this.state.fields.password} onChange={this.handleChange} />
                        <div className="errorvalue">{this.state.errors.password}</div>
                        <input type="text" placeholder="Retype Password"  name="rpassword" value={this.state.fields.rpassword} onChange={this.handleChange} />
                        <div className="errorvalue">{this.state.errors.rpassword}</div>
                        <input type="submit" value="Submit" className="btn" />
                    </form>
                </div>
                <img src="https://img.freepik.com/free-vector/pharmacy-with-pharmacist-woman-counter-desk_107791-2214.jpg"/>
            </div>
        )
    }
}
export default PRegistration;