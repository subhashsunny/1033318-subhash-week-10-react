import './App.css';
import AxiTest from './AxiExample2';

function App() {
  return (
  <AxiTest/>
  );
}

export default App;