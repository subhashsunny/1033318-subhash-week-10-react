import React from 'react';
import axios from 'axios';

export default class AxiEXample2 extends React.Component {

    state = {
        holders: []
    }

    componentDidMount() {
        axios.get('https://cat-fact.herokuapp.com/facts/')
            .then(res => {
                const holders = res.data;
                console.log(this.state.holders)
                this.setState({ holders: holders });
            })
    }

    render() {
        return (
        <table border={1}>
        <thead>
           <tr>
             <th>title</th>
           <th>body</th>
           <th>type</th>
           </tr>
        </thead>
        <tbody>
            {
            this.state.holders
                .map(holder =>
                    <tr key={holder.id}>
                        <td>{holder._id}</td>
                      <td>{holder.text}</td>
                      <td>{holder.type}</td>       
                      </tr>
                )
                }
    </tbody>    
        </table >
        )        
    }
}